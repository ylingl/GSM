package tsme.table.deviceDR.DAO;

import tsme.DAO.mainDAOPractice.TsmeMainDAOPractice;
import tsme.table.deviceDR.bean.DEVICEDR;

public interface DeviceDRDAO extends TsmeMainDAOPractice<DEVICEDR> {

}
