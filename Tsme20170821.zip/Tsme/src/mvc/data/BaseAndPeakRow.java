package mvc.data;

public class BaseAndPeakRow {
	
	private int baseRow;
	
	private int peakRow;

	public int getBaseRow() {
		return baseRow;
	}

	public void setBaseRow(int baseRow) {
		this.baseRow = baseRow;
	}

	public int getPeakRow() {
		return peakRow;
	}

	public void setPeakRow(int peakRow) {
		this.peakRow = peakRow;
	}

}
