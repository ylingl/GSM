package tsme.bean.mainBeanPractice;

import tsme.bean.mainBaseBean.AutoInsertDataToTsmeBean;

public abstract class TsmeMainBeanPracticeImpl extends AutoInsertDataToTsmeBean implements TsmeMainBeanPractice {

	/**
	 * 
	 */
	private static final long serialVersionUID = 5325021766348910821L;	

}
