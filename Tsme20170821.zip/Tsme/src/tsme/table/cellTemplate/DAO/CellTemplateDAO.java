package tsme.table.cellTemplate.DAO;

import tsme.DAO.mainDAOPractice.TsmeMainDAOPractice;
import tsme.table.cellTemplate.bean.CELLTEMPLATE;

public interface CellTemplateDAO extends TsmeMainDAOPractice<CELLTEMPLATE>{

}
