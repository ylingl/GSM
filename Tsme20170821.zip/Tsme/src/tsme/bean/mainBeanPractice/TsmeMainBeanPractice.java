package tsme.bean.mainBeanPractice;

import tsme.bean.mainBaseBean.TsmeMainBaseBean;

public interface TsmeMainBeanPractice extends TsmeMainBaseBean{

}
