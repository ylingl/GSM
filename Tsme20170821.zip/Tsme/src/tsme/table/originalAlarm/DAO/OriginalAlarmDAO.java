package tsme.table.originalAlarm.DAO;

import tsme.DAO.mainDAOPractice.TsmeMainDAOPractice;
import tsme.table.originalAlarm.bean.ORIGINALALARM;

public interface OriginalAlarmDAO extends TsmeMainDAOPractice<ORIGINALALARM> {

}
