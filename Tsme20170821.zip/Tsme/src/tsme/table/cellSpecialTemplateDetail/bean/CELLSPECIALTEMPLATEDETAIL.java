package tsme.table.cellSpecialTemplateDetail.bean;

import tsme.bean.mainBeanPractice.TsmeMainBeanPractice;
import tsme.bean.mainBeanPractice.TsmeMainBeanPracticeImpl;

public class CELLSPECIALTEMPLATEDETAIL extends TsmeMainBeanPracticeImpl implements TsmeMainBeanPractice{

	/**
	 * 
	 */
	private static final long serialVersionUID = -6181687452344746854L;

	private String id;
	
	private String cellSpecialTemplate_id;
	
	private int C_I;
	
	private int frequency;
	
	private String BCCH;
	
	private String cell;
	
	private String precision;
	
	private String TRX;
	
	private String elements;
	
	private String value;
	
	@Override
	public void setId(String id) {
		// TODO Auto-generated method stub
		this.id = id;
	}

	public String getCellSpecialTemplate_id() {
		return cellSpecialTemplate_id;
	}

	public void setCellSpecialTemplate_id(String cellSpecialTemplate_id) {
		this.cellSpecialTemplate_id = cellSpecialTemplate_id;
	}

	public int getC_I() {
		return C_I;
	}

	public void setC_I(int c_I) {
		C_I = c_I;
	}

	public int getFrequency() {
		return frequency;
	}

	public void setFrequency(int frequency) {
		this.frequency = frequency;
	}

	public String getBCCH() {
		return BCCH;
	}

	public void setBCCH(String bCCH) {
		BCCH = bCCH;
	}

	public String getCell() {
		return cell;
	}

	public void setCell(String cell) {
		this.cell = cell;
	}

	public String getPrecision() {
		return precision;
	}

	public void setPrecision(String precision) {
		this.precision = precision;
	}

	public String getTRX() {
		return TRX;
	}

	public void setTRX(String tRX) {
		TRX = tRX;
	}

	public String getElements() {
		return elements;
	}

	public void setElements(String elements) {
		this.elements = elements;
	}

	public String getValue() {
		return value;
	}

	public void setValue(String value) {
		this.value = value;
	}

	public String getId() {
		return id;
	}
}
