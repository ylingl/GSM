package tsme.table.deviceWL.DAO;

import tsme.DAO.mainDAOPractice.TsmeMainDAOPractice;
import tsme.table.deviceWL.bean.DEVICEWL;

public interface DeviceWLDAO extends TsmeMainDAOPractice<DEVICEWL>{

}
