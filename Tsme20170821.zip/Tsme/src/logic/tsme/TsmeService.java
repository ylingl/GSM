package logic.tsme;


public interface TsmeService {

}
