package tsme.table.avgData.DAO;

import tsme.DAO.mainDAOPractice.TsmeMainDAOPractice;
import tsme.table.avgData.bean.AVGDATA;

public interface AvgDataDAO extends TsmeMainDAOPractice<AVGDATA>{

}
