package mvc.data;

public class WarningTemplateRecPara {
	
	private String template_name;
	
	private float startFrequency0;
	
	private float stopFrequency0;
	
	private float startFrequency1;
	
	private float stopFrequency1;
	
	private float startFrequency2;
	
	private float stopFrequency2;
	
	private int fftSize;
	
	private int bandWidth;
	
	private int maxMeans;

	public String getTemplate_name() {
		return template_name;
	}

	public void setTemplate_name(String template_name) {
		this.template_name = template_name;
	}

	public int getFftSize() {
		return fftSize;
	}

	public void setFftSize(int fftSize) {
		this.fftSize = fftSize;
	}

	public int getMaxMeans() {
		return maxMeans;
	}

	public void setMaxMeans(int maxMeans) {
		this.maxMeans = maxMeans;
	}

	public int getBandWidth() {
		return bandWidth;
	}

	public void setBandWidth(int bandWidth) {
		this.bandWidth = bandWidth;
	}

	public float getStartFrequency0() {
		return startFrequency0;
	}

	public void setStartFrequency0(float startFrequency0) {
		this.startFrequency0 = startFrequency0;
	}

	public float getStopFrequency0() {
		return stopFrequency0;
	}

	public void setStopFrequency0(float stopFrequency0) {
		this.stopFrequency0 = stopFrequency0;
	}

	public float getStartFrequency1() {
		return startFrequency1;
	}

	public void setStartFrequency1(float startFrequency1) {
		this.startFrequency1 = startFrequency1;
	}

	public float getStopFrequency1() {
		return stopFrequency1;
	}

	public void setStopFrequency1(float stopFrequency1) {
		this.stopFrequency1 = stopFrequency1;
	}

	public float getStartFrequency2() {
		return startFrequency2;
	}

	public void setStartFrequency2(float startFrequency2) {
		this.startFrequency2 = startFrequency2;
	}

	public float getStopFrequency2() {
		return stopFrequency2;
	}

	public void setStopFrequency2(float stopFrequency2) {
		this.stopFrequency2 = stopFrequency2;
	}

}
