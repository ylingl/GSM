package tsme.table.deviceSignal.DAO;

import tsme.DAO.mainDAOPractice.TsmeMainDAOPractice;
import tsme.table.deviceSignal.bean.DEVICESIGNAL;

public interface DeviceSignalDAO extends TsmeMainDAOPractice<DEVICESIGNAL>{

}
