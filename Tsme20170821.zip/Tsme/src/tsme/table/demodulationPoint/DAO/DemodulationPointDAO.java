package tsme.table.demodulationPoint.DAO;

import tsme.DAO.mainDAOPractice.TsmeMainDAOPractice;
import tsme.table.demodulationPoint.bean.DEMODULATIONPOINT;

public interface DemodulationPointDAO extends TsmeMainDAOPractice<DEMODULATIONPOINT>{

}
