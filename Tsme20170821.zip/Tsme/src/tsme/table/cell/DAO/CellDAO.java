package tsme.table.cell.DAO;

import tsme.DAO.mainDAOPractice.TsmeMainDAOPractice;
import tsme.table.cell.bean.CELL;

public interface CellDAO extends TsmeMainDAOPractice<CELL>{
}
