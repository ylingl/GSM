package tsme.table.avgData.DAO;

import org.springframework.stereotype.Repository;

import tsme.DAO.mainDAOPractice.TsmeMainDAOPracticeImpl;
import tsme.table.avgData.bean.AVGDATA;

@Repository("avgDataDAO")
public class AvgDataDAOImpl extends TsmeMainDAOPracticeImpl<AVGDATA> implements AvgDataDAO{

}
