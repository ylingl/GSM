package tsme.table.frequencyBand.DAO;

import tsme.DAO.mainDAOPractice.TsmeMainDAOPractice;
import tsme.table.frequencyBand.bean.FREQUENCYBAND;

public interface FrequencyBandDAO extends TsmeMainDAOPractice<FREQUENCYBAND>{

}
