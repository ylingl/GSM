package tsme.table.deviceLoginLog.DAO;

import tsme.DAO.mainDAOPractice.TsmeMainDAOPractice;
import tsme.table.deviceLoginLog.bean.DEVICELOGINLOG;

public interface DeviceLoginLogDAO extends TsmeMainDAOPractice<DEVICELOGINLOG>{

}
