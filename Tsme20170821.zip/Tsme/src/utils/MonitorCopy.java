package utils;

import mvc.spectra.SpectraPrePara;

public class MonitorCopy {

	private SpectraPrePara spectraPrePara;
	
	//private SpectraData spectraData;

	/*public SpectraData getSpectraData() {
		return spectraData;
	}

	public void setSpectraData(SpectraData spectraData) {
		this.spectraData = spectraData;
	}*/

	public SpectraPrePara getSpectraPrePara() {
		return spectraPrePara;
	}

	public void setSpectraPrePara(SpectraPrePara spectraPrePara) {
		this.spectraPrePara = spectraPrePara;
	}
	
}
