package tsme.table.deviceWT.DAO;

import tsme.DAO.mainDAOPractice.TsmeMainDAOPractice;
import tsme.table.deviceWT.bean.DEVICEWT;

public interface DeviceWTDAO extends TsmeMainDAOPractice<DEVICEWT>{

}
