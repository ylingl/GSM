package tsme.table.cellSpecialTemplateDetail.DAO;

import tsme.DAO.mainDAOPractice.TsmeMainDAOPractice;
import tsme.table.cellSpecialTemplateDetail.bean.CELLSPECIALTEMPLATEDETAIL;

public interface CellSpecialTemplateDetailDAO extends TsmeMainDAOPractice<CELLSPECIALTEMPLATEDETAIL>{

}
