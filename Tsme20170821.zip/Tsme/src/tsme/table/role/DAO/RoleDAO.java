package tsme.table.role.DAO;

import tsme.DAO.mainDAOPractice.TsmeMainDAOPractice;
import tsme.table.role.bean.ROLE;

public interface RoleDAO extends TsmeMainDAOPractice<ROLE>{

}
