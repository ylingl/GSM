package tsme.table.bsCOP.DAO;

import tsme.DAO.mainDAOPractice.TsmeMainDAOPractice;
import tsme.table.bsCOP.bean.BSCOP;

public interface BsCOPDAO extends TsmeMainDAOPractice<BSCOP>{

}
