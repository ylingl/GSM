package tsme.table.deviceDP.DAO;

import tsme.DAO.mainDAOPractice.TsmeMainDAOPractice;
import tsme.table.deviceDP.bean.DEVICEDP;

public interface DeviceDPDAO extends TsmeMainDAOPractice<DEVICEDP>{

}
