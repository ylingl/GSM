package tsme.table.avgExtreme.DAO;

import tsme.DAO.mainDAOPractice.TsmeMainDAOPractice;
import tsme.table.avgExtreme.bean.AVGEXTREME;

public interface AvgExtremeDAO extends TsmeMainDAOPractice<AVGEXTREME>{

}
