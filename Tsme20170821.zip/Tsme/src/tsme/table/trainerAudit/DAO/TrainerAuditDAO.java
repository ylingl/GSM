package tsme.table.trainerAudit.DAO;

import tsme.DAO.mainDAOPractice.TsmeMainDAOPractice;
import tsme.table.trainerAudit.bean.TRAINERAUDIT;

public interface TrainerAuditDAO extends TsmeMainDAOPractice<TRAINERAUDIT> {

}
