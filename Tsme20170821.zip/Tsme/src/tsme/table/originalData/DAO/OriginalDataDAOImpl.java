package tsme.table.originalData.DAO;

import org.springframework.stereotype.Repository;

import tsme.DAO.mainDAOPractice.TsmeMainDAOPracticeImpl;
import tsme.table.originalData.bean.ORIGINALDATA;

@Repository("originalDataDAO")
public class OriginalDataDAOImpl extends TsmeMainDAOPracticeImpl<ORIGINALDATA> implements OriginalDataDAO{

}
