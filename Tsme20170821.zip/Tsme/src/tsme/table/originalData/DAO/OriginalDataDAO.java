package tsme.table.originalData.DAO;

import tsme.DAO.mainDAOPractice.TsmeMainDAOPractice;
import tsme.table.originalData.bean.ORIGINALDATA;

public interface OriginalDataDAO extends TsmeMainDAOPractice<ORIGINALDATA>{

}
