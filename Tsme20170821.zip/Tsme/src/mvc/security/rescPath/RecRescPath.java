package mvc.security.rescPath;

public class RecRescPath {
	
	private String uri;
	
	private String function;

	public String getUri() {
		return uri;
	}

	public void setUri(String uri) {
		this.uri = uri;
	}

	public String getFunction() {
		return function;
	}

	public void setFunction(String function) {
		this.function = function;
	}
}
