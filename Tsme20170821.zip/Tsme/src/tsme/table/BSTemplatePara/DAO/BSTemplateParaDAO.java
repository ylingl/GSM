package tsme.table.BSTemplatePara.DAO;

import tsme.DAO.mainDAOPractice.TsmeMainDAOPractice;
import tsme.table.BSTemplatePara.bean.BSTEMPLATEPARA;

public interface BSTemplateParaDAO extends TsmeMainDAOPractice<BSTEMPLATEPARA>{

}
