package tsme.table.result.DAO;

import tsme.DAO.mainDAOPractice.TsmeMainDAOPractice;
import tsme.table.result.bean.RESULT;

public interface ResultDAO extends TsmeMainDAOPractice<RESULT>{

}
