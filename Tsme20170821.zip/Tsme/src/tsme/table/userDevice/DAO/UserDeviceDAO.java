package tsme.table.userDevice.DAO;

import tsme.DAO.mainDAOPractice.TsmeMainDAOPractice;
import tsme.table.userDevice.bean.USERDEVICE;

public interface UserDeviceDAO extends TsmeMainDAOPractice<USERDEVICE>{

}
