package tsme.table.deviceFB.DAO;

import tsme.DAO.mainDAOPractice.TsmeMainDAOPractice;
import tsme.table.deviceFB.bean.DEVICEFB;

public interface DeviceFBDAO extends TsmeMainDAOPractice<DEVICEFB>{

}
