package tsme.table.parameter.DAO;

import tsme.DAO.mainDAOPractice.TsmeMainDAOPractice;
import tsme.table.parameter.bean.PARAMETER;

public interface ParameterDAO extends TsmeMainDAOPractice<PARAMETER>{

}
