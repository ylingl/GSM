package tsme.table.bsLocation.DAO;

import java.util.List;

import tsme.DAO.mainDAOPractice.TsmeMainDAOPractice;
import tsme.table.bsLocation.bean.BSLOCATION;

public interface BsLocationDAO extends TsmeMainDAOPractice<BSLOCATION>{
	
	public List<BSLOCATION> getBsLocation();
}
