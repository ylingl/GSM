package tsme.table.device.DAO;

import tsme.DAO.mainDAOPractice.TsmeMainDAOPractice;
import tsme.table.device.bean.DEVICE;

public interface DeviceDAO extends TsmeMainDAOPractice<DEVICE>{

}
