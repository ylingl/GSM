package tsme.table.template.DAO;

import tsme.DAO.mainDAOPractice.TsmeMainDAOPractice;
import tsme.table.template.bean.TEMPLATE;

public interface TemplateDAO extends TsmeMainDAOPractice<TEMPLATE>{

}
