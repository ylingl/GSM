package tsme.table.originalDemod.DAO;

import tsme.DAO.mainDAOPractice.TsmeMainDAOPractice;
import tsme.table.originalDemod.bean.ORIGINALDEMOD;

public interface OriginalDemodDAO extends TsmeMainDAOPractice<ORIGINALDEMOD>{

}
