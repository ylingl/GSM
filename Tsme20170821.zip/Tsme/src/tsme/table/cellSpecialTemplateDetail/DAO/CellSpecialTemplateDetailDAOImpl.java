package tsme.table.cellSpecialTemplateDetail.DAO;

import org.springframework.stereotype.Repository;

import tsme.DAO.mainDAOPractice.TsmeMainDAOPracticeImpl;
import tsme.table.cellSpecialTemplateDetail.bean.CELLSPECIALTEMPLATEDETAIL;

@Repository("cellSpecialTemplateDetailDAO")
public class CellSpecialTemplateDetailDAOImpl extends TsmeMainDAOPracticeImpl<CELLSPECIALTEMPLATEDETAIL> implements CellSpecialTemplateDetailDAO{

}
