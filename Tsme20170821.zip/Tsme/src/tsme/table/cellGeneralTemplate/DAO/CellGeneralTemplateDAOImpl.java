package tsme.table.cellGeneralTemplate.DAO;

import org.springframework.stereotype.Repository;

import tsme.DAO.mainDAOPractice.TsmeMainDAOPracticeImpl;
import tsme.table.cellGeneralTemplate.bean.CELLGENERALTEMPLATE;

@Repository("cellGeneralTemplateDAO")
public class CellGeneralTemplateDAOImpl extends TsmeMainDAOPracticeImpl<CELLGENERALTEMPLATE> implements CellGeneralTemplateDAO{

}
