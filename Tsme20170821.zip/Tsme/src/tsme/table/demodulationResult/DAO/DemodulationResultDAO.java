package tsme.table.demodulationResult.DAO;

import tsme.DAO.mainDAOPractice.TsmeMainDAOPractice;
import tsme.table.demodulationResult.bean.DEMODULATIONRESULT;

public interface DemodulationResultDAO extends TsmeMainDAOPractice<DEMODULATIONRESULT> {

}
