package tsme.table.cellSpecialTemplate.DAO;

import tsme.DAO.mainDAOPractice.TsmeMainDAOPractice;
import tsme.table.cellSpecialTemplate.bean.CELLSPECIALTEMPLATE;

public interface CellSpecialTemplateDAO extends TsmeMainDAOPractice<CELLSPECIALTEMPLATE>{

}
