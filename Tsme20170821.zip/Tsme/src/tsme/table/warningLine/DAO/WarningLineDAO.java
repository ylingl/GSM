package tsme.table.warningLine.DAO;

import tsme.DAO.mainDAOPractice.TsmeMainDAOPractice;
import tsme.table.warningLine.bean.WARNINGLINE;

public interface WarningLineDAO extends TsmeMainDAOPractice<WARNINGLINE> {
	
}
