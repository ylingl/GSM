package tsme.table.BSTemplatePara.DAO;

import org.springframework.stereotype.Repository;

import tsme.DAO.mainDAOPractice.TsmeMainDAOPracticeImpl;
import tsme.table.BSTemplatePara.bean.BSTEMPLATEPARA;

@Repository("bsTemplateParaDAO")
public class BSTemplateParaDAOImpl extends TsmeMainDAOPracticeImpl<BSTEMPLATEPARA> implements BSTemplateParaDAO{

}
