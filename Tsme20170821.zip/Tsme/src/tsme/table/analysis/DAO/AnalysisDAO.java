package tsme.table.analysis.DAO;

import tsme.DAO.mainDAOPractice.TsmeMainDAOPractice;
import tsme.table.analysis.bean.ANALYSIS;

public interface AnalysisDAO extends TsmeMainDAOPractice<ANALYSIS>{

}
