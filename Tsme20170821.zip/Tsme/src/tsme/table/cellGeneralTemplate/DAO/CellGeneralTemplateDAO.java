package tsme.table.cellGeneralTemplate.DAO;

import tsme.DAO.mainDAOPractice.TsmeMainDAOPractice;
import tsme.table.cellGeneralTemplate.bean.CELLGENERALTEMPLATE;

public interface CellGeneralTemplateDAO extends TsmeMainDAOPractice<CELLGENERALTEMPLATE>{

}
