package tsme.DAO.mainDAOPractice;

import tsme.DAO.mainBaseDAO.TsmeMainBaseDAO;

public abstract class TsmeMainDAOPracticeImpl<T> extends TsmeMainBaseDAO<T> implements TsmeMainDAOPractice<T>{	

}
