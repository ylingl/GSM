package tsme.table.department.DAO;

import tsme.DAO.mainDAOPractice.TsmeMainDAOPractice;
import tsme.table.department.bean.DEPARTMENT;

public interface DepartmentDAO extends TsmeMainDAOPractice<DEPARTMENT>{

}
