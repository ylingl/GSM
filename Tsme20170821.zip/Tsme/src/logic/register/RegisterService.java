package logic.register;

public interface RegisterService {

	public boolean register(String stamp, String applyId, String password);
	
}
