package logic.tsme;

import org.springframework.stereotype.Service;

@Service("tsmeService")
public class TsmeServiceImpl implements TsmeService{

}
