package tsme.table.controlProperty.DAO;

import tsme.DAO.mainDAOPractice.TsmeMainDAOPractice;
import tsme.table.controlProperty.bean.CONTROLPROPERTY;

public interface ControlPropertyDAO extends TsmeMainDAOPractice<CONTROLPROPERTY>{

}
