package logic.client;

public interface ClientService {
	
}
