package tsme.table.trainingData.DAO;

import tsme.DAO.mainDAOPractice.TsmeMainDAOPractice;
import tsme.table.trainingData.bean.TRAININGDATA;

public interface TrainingDataDAO extends TsmeMainDAOPractice<TRAININGDATA>{

}
