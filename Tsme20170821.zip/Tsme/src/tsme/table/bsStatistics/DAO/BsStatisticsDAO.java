package tsme.table.bsStatistics.DAO;

import tsme.DAO.mainDAOPractice.TsmeMainDAOPractice;
import tsme.table.bsStatistics.bean.BSSTATISTICS;

public interface BsStatisticsDAO extends TsmeMainDAOPractice<BSSTATISTICS>{

}
