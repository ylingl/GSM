package tsme.table.archive.DAO;

import tsme.DAO.mainDAOPractice.TsmeMainDAOPractice;
import tsme.table.archive.bean.ARCHIVE;

public interface ArchiveDAO extends TsmeMainDAOPractice<ARCHIVE>{

}
