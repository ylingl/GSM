package tsme.table.cellLocation.DAO;

import tsme.DAO.mainDAOPractice.TsmeMainDAOPractice;
import tsme.table.cellLocation.bean.CELLLOCATION;

public interface CellLocationDAO extends TsmeMainDAOPractice<CELLLOCATION>{

}
