package tsme.table.deviceCOP.DAO;

import tsme.DAO.mainDAOPractice.TsmeMainDAOPractice;
import tsme.table.deviceCOP.bean.DEVICECOP;

public interface DeviceCOPDAO extends TsmeMainDAOPractice<DEVICECOP>{

}
