package logic.client;

import org.springframework.stereotype.Service;

@Service("clientService")
public class ClientServiceImpl implements ClientService {

}
