package logic.security.login;

public interface LoginService {

	public boolean verifyUsernameAndPasswordForWeb(String username, String password);
	
}
